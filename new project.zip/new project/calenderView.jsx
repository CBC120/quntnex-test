import React from 'react';
import FullCalendar from '@fullcalendar/react';
import dayGridPlugin from '@fullcalendar/daygrid';

function CalendarView() {
  const events = [
    { title: 'Meeting with XYZ', start: '2025-01-03' },
    { title: 'Follow-up with ABC', start: '2025-01-05' },
  ];

  return (
    <div className="calendar-view">
      <h2>Calendar</h2>
      <FullCalendar plugins={[dayGridPlugin]} events={events} />
    </div>
  );
}

export default CalendarView;
