import axios from 'axios';

const api = axios.create({
  baseURL: 'https://mockapi.io/api/v1', // Replace with your API endpoint
});

export const getCompanies = () => api.get('/companies');
export const addCompany = (data) => api.post('/companies', data);
export const getMethods = () => api.get('/methods');
export const addMethod = (data) => api.post('/methods', data);

export default api;
