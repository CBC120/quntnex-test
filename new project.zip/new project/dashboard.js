import React, { useState, useEffect } from 'react';
import { getCompanies } from '../../services/api';

function Dashboard() {
  const [companies, setCompanies] = useState([]);

  useEffect(() => {
    getCompanies().then((response) => setCompanies(response.data));
  }, []);

  return (
    <div className="dashboard">
      <h2>Dashboard</h2>
      <table>
        <thead>
          <tr>
            <th>Company Name</th>
            <th>Last Five Communications</th>
            <th>Next Scheduled Communication</th>
          </tr>
        </thead>
        <tbody>
          {companies.map((company) => (
            <tr key={company.id}>
              <td>{company.name}</td>
              <td>{company.lastCommunications.join(', ')}</td>
              <td>{company.nextCommunication}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export default Dashboard;
