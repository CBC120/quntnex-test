import React, { useState } from 'react';
import { addCompany } from '../../services/api';

function CompanyManagement() {
  const [name, setName] = useState('');
  const handleSubmit = (e) => {
    e.preventDefault();
    addCompany({ name }).then(() => alert('Company added successfully'));
  };

  return (
    <div>
      <h2>Company Management</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Company Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <button type="submit">Add Company</button>
      </form>
    </div>
  );
}

export default CompanyManagement;
