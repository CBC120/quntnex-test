import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Shared/Navbar';
import Dashboard from './components/User/Dashboard';
import CalendarView from './components/User/CalendarView';
import CompanyManagement from './components/Admin/CompanyManagement';
import CommunicationMethods from './components/Admin/CommunicationMethods';

function App() {
  return (
    <Router>
      <Navbar />
      <Routes>
        <Route path="/" element={<Dashboard />} />
        <Route path="/calendar" element={<CalendarView />} />
        <Route path="/admin/companies" element={<CompanyManagement />} />
        <Route path="/admin/methods" element={<CommunicationMethods />} />
      </Routes>
    </Router>
  );
}

export default App;
